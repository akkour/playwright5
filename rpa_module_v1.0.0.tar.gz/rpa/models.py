"""
RPA Models - Pydantic models pour les requêtes/réponses RPA
Version: 1.0.0
"""

from typing import Dict, List, Optional, Any
from pydantic import BaseModel, Field, validator
from datetime import datetime


class QuoteFormData(BaseModel):
    """Données du formulaire de tarification"""
    # Auto/Moto
    driver_age: Optional[int] = Field(None, ge=18, le=99)
    vehicle_brand: Optional[str] = None
    vehicle_model: Optional[str] = None
    vehicle_year: Optional[int] = Field(None, ge=1990, le=2025)
    usage: Optional[str] = Field(None, description="private, professional, mixed")
    driver_license_years: Optional[int] = Field(None, ge=0)
    
    # Habitation
    property_type: Optional[str] = Field(None, description="apartment, house, villa")
    surface_area: Optional[int] = Field(None, ge=10, le=1000)
    construction_year: Optional[int] = Field(None, ge=1900, le=2025)
    security_equipment: Optional[List[str]] = Field(default_factory=list)
    
    # Santé
    birth_date: Optional[str] = None
    gender: Optional[str] = Field(None, description="M, F")
    occupation: Optional[str] = None
    
    # Emprunteur
    loan_amount: Optional[float] = Field(None, ge=0)
    loan_duration_years: Optional[int] = Field(None, ge=1, le=30)
    
    # Autres champs génériques
    postal_code: Optional[str] = None
    city: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    
    @validator('usage')
    def validate_usage(cls, v):
        if v and v not in ['private', 'professional', 'mixed']:
            raise ValueError('usage must be private, professional, or mixed')
        return v
    
    @validator('gender')
    def validate_gender(cls, v):
        if v and v not in ['M', 'F']:
            raise ValueError('gender must be M or F')
        return v


class RPAQuoteRequest(BaseModel):
    """Requête de scraping de devis RPA"""
    job_id: str = Field(..., description="ID unique du job")
    callback_url: str = Field(..., description="URL de callback pour le résultat")
    product_code: str = Field(..., description="auto, moto, habitation, sante, emprunteur")
    insurer_name: str = Field(..., description="Nom de l'assureur")
    form_data: QuoteFormData
    config_yaml: str = Field(..., description="Configuration YAML de l'assureur")
    timeout: Optional[int] = Field(60, ge=10, le=300, description="Timeout en secondes")
    
    @validator('product_code')
    def validate_product_code(cls, v):
        allowed = ['auto', 'moto', 'habitation', 'sante', 'emprunteur', 'prevoyance', 'rc_pro', 'animaux']
        if v not in allowed:
            raise ValueError(f'product_code must be one of {allowed}')
        return v


class CoverageDetail(BaseModel):
    """Détail d'une garantie"""
    name: str
    included: bool = True
    limit: Optional[str] = None
    deductible: Optional[str] = None


class QuoteResult(BaseModel):
    """Résultat d'un scraping de devis"""
    price_monthly: Optional[float] = Field(None, description="Prix mensuel")
    price_yearly: Optional[float] = Field(None, description="Prix annuel")
    currency: str = Field(default="MAD", description="Devise")
    coverage_details: Dict[str, Any] = Field(default_factory=dict)
    quote_reference: Optional[str] = Field(None, description="Référence du devis")
    pdf_url: Optional[str] = Field(None, description="URL du PDF")
    formula_name: Optional[str] = Field(None, description="Nom de la formule")
    insurer_logo_url: Optional[str] = None
    valid_until: Optional[str] = None
    additional_info: Dict[str, Any] = Field(default_factory=dict)


class RPAQuoteResponse(BaseModel):
    """Réponse du scraping RPA"""
    status: str = Field(..., description="success, failed, timeout")
    job_id: str
    result: Optional[QuoteResult] = None
    error_message: Optional[str] = None
    duration_ms: int
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    screenshots: List[str] = Field(default_factory=list, description="URLs des screenshots")
    
    @validator('status')
    def validate_status(cls, v):
        if v not in ['success', 'failed', 'timeout']:
            raise ValueError('status must be success, failed, or timeout')
        return v


class InsurerConfig(BaseModel):
    """Configuration d'un assureur parsée depuis YAML"""
    insurer_name: str
    base_url: str
    simulator_path: Optional[str] = None
    country: str = Field(default="MA")
    complexity: int = Field(..., ge=1, le=5)
    rating: Optional[float] = Field(None, ge=0, le=5)
    
    workflows: Dict[str, Any] = Field(default_factory=dict)
    validation_rules: List[Dict[str, Any]] = Field(default_factory=list)
    selectors: Dict[str, Any] = Field(default_factory=dict)
    
    # Configuration avancée
    requires_cookies: bool = Field(default=False)
    has_captcha: bool = Field(default=False)
    wait_after_load: int = Field(default=2000, description="Temps d'attente après chargement (ms)")
    max_retries: int = Field(default=3, ge=1, le=5)
    screenshot_on_error: bool = Field(default=True)


class RPAStats(BaseModel):
    """Statistiques RPA"""
    total_jobs: int = 0
    successful_jobs: int = 0
    failed_jobs: int = 0
    timeout_jobs: int = 0
    average_duration_ms: float = 0.0
    jobs_by_insurer: Dict[str, int] = Field(default_factory=dict)
    jobs_by_product: Dict[str, int] = Field(default_factory=dict)
    success_rate: float = 0.0
    last_updated: str = Field(default_factory=lambda: datetime.now().isoformat())


class ConfigReloadRequest(BaseModel):
    """Requête de rechargement de configuration"""
    force: bool = Field(default=False, description="Forcer le rechargement même si cache valide")


class ConfigReloadResponse(BaseModel):
    """Réponse du rechargement de configuration"""
    success: bool
    message: str
    configs_loaded: int = 0
    insurers: List[str] = Field(default_factory=list)
    timestamp: str = Field(default_factory=lambda: datetime.now().isoformat())
    errors: List[str] = Field(default_factory=list)
