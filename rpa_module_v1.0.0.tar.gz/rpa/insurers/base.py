"""
RPA BaseInsurer - Classe de base abstraite pour tous les scrapers d'assureurs
Version: 1.0.0
"""

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
from datetime import datetime
from playwright.async_api import Page, TimeoutError as PlaywrightTimeoutError

from .models import InsurerConfig, QuoteFormData, QuoteResult
from .exceptions import (
    WorkflowExecutionError,
    FormFillingError,
    ExtractionError,
    SelectorNotFoundError,
    TimeoutError as RPATimeoutError,
    NavigationError,
    CaptchaDetectedError
)

logger = logging.getLogger(__name__)


class BaseInsurer(ABC):
    """
    Classe abstraite pour les scrapers d'assureurs
    
    Fournit les méthodes communes et définit l'interface que tous les
    scrapers spécifiques doivent implémenter.
    """
    
    def __init__(self, config: InsurerConfig):
        self.config = config
        self.name = config.insurer_name
        self.base_url = config.base_url
        self.screenshots = []  # Pour debug
        
        logger.info(f"Initialized {self.__class__.__name__} for {self.name}")
    
    @abstractmethod
    async def scrape_quote(
        self,
        page: Page,
        product_code: str,
        form_data: QuoteFormData
    ) -> QuoteResult:
        """
        Méthode abstraite à implémenter par chaque scraper
        
        Args:
            page: Page Playwright
            product_code: Code du produit (auto, moto, etc.)
            form_data: Données du formulaire
            
        Returns:
            Résultat du scraping (prix, garanties, etc.)
        """
        pass
    
    async def execute_workflow(
        self,
        page: Page,
        workflow: Dict,
        form_data: QuoteFormData
    ) -> QuoteResult:
        """
        Exécute un workflow YAML générique
        
        Cette méthode peut être utilisée par les scrapers qui suivent
        exactement le workflow YAML, ou être surchargée pour une logique custom.
        """
        logger.info(f"[{self.name}] Executing workflow with {len(workflow.get('steps', []))} steps")
        
        extracted_data = {}
        
        try:
            for idx, step in enumerate(workflow.get('steps', [])):
                action = step.get('action')
                logger.debug(f"[{self.name}] Step {idx+1}: {action}")
                
                if action == 'navigate':
                    await self._step_navigate(page, step)
                
                elif action == 'wait':
                    await self._step_wait(page, step)
                
                elif action == 'wait_for':
                    await self._step_wait_for(page, step)
                
                elif action == 'fill_form':
                    await self._step_fill_form(page, step, form_data)
                
                elif action == 'click':
                    await self._step_click(page, step)
                
                elif action == 'select':
                    await self._step_select(page, step, form_data)
                
                elif action == 'extract':
                    extracted_data = await self._step_extract(page, step)
                
                elif action == 'screenshot':
                    await self._step_screenshot(page, step)
                
                elif action == 'scroll':
                    await self._step_scroll(page, step)
                
                else:
                    logger.warning(f"[{self.name}] Unknown action: {action}")
            
            # Construire le résultat
            if not extracted_data:
                raise ExtractionError("No data extracted from workflow", insurer=self.name)
            
            return self._build_quote_result(extracted_data)
            
        except PlaywrightTimeoutError as e:
            logger.error(f"[{self.name}] Playwright timeout: {e}")
            raise RPATimeoutError(f"Timeout during workflow execution: {e}", insurer=self.name)
        
        except Exception as e:
            logger.error(f"[{self.name}] Workflow execution failed: {e}")
            raise WorkflowExecutionError(f"Workflow failed: {e}", insurer=self.name)
    
    async def _step_navigate(self, page: Page, step: Dict):
        """Step: Navigation vers une URL"""
        url = step.get('url', '')
        
        # Remplacer les variables
        url = url.replace('{{base_url}}', self.base_url)
        url = url.replace('{{simulator_path}}', self.config.simulator_path or '')
        
        logger.info(f"[{self.name}] Navigating to: {url}")
        
        try:
            timeout = step.get('timeout', 30000)
            await page.goto(url, wait_until='domcontentloaded', timeout=timeout)
            
            # Attente après chargement (si configuré)
            if self.config.wait_after_load > 0:
                await asyncio.sleep(self.config.wait_after_load / 1000)
            
        except Exception as e:
            raise NavigationError(f"Failed to navigate to {url}: {e}", insurer=self.name)
    
    async def _step_wait(self, page: Page, step: Dict):
        """Step: Attendre un délai fixe"""
        duration = step.get('duration', 1000)  # ms
        logger.debug(f"[{self.name}] Waiting {duration}ms")
        await asyncio.sleep(duration / 1000)
    
    async def _step_wait_for(self, page: Page, step: Dict):
        """Step: Attendre qu'un sélecteur soit présent"""
        selector = step.get('selector')
        if not selector:
            raise WorkflowExecutionError("Missing 'selector' in wait_for step", insurer=self.name)
        
        timeout = step.get('timeout', 10000)
        
        try:
            logger.debug(f"[{self.name}] Waiting for selector: {selector}")
            await page.wait_for_selector(selector, timeout=timeout)
        except PlaywrightTimeoutError:
            raise SelectorNotFoundError(selector, insurer=self.name)
    
    async def _step_fill_form(self, page: Page, step: Dict, form_data: QuoteFormData):
        """Step: Remplir un formulaire"""
        selectors = step.get('selectors', {})
        
        for field, selector in selectors.items():
            value = getattr(form_data, field, None)
            
            if value is None:
                logger.warning(f"[{self.name}] Field '{field}' not provided in form_data")
                continue
            
            try:
                logger.debug(f"[{self.name}] Filling {field} = {value}")
                await page.fill(selector, str(value))
                await asyncio.sleep(0.5)  # Délai entre champs
                
            except Exception as e:
                raise FormFillingError(
                    f"Failed to fill field '{field}' (selector: {selector}): {e}",
                    insurer=self.name
                )
    
    async def _step_click(self, page: Page, step: Dict):
        """Step: Cliquer sur un élément"""
        selector = step.get('selector')
        if not selector:
            raise WorkflowExecutionError("Missing 'selector' in click step", insurer=self.name)
        
        try:
            logger.debug(f"[{self.name}] Clicking: {selector}")
            await page.click(selector)
            
            # Attendre après clic si spécifié
            wait_after = step.get('wait_after', 1000)
            await asyncio.sleep(wait_after / 1000)
            
        except Exception as e:
            raise WorkflowExecutionError(f"Failed to click {selector}: {e}", insurer=self.name)
    
    async def _step_select(self, page: Page, step: Dict, form_data: QuoteFormData):
        """Step: Sélectionner une option dans un select"""
        selector = step.get('selector')
        field = step.get('field')
        
        if not selector or not field:
            raise WorkflowExecutionError("Missing 'selector' or 'field' in select step", insurer=self.name)
        
        value = getattr(form_data, field, None)
        if value is None:
            logger.warning(f"[{self.name}] Field '{field}' not provided for select")
            return
        
        try:
            logger.debug(f"[{self.name}] Selecting {field} = {value}")
            await page.select_option(selector, str(value))
            
        except Exception as e:
            raise FormFillingError(f"Failed to select {field}: {e}", insurer=self.name)
    
    async def _step_extract(self, page: Page, step: Dict) -> Dict[str, Any]:
        """Step: Extraire des données de la page"""
        fields = step.get('fields', {})
        extracted = {}
        
        for field_name, selector in fields.items():
            try:
                # Attendre que l'élément soit visible
                await page.wait_for_selector(selector, timeout=5000, state='visible')
                
                # Extraire le texte
                element = await page.query_selector(selector)
                if element:
                    text = await element.text_content()
                    extracted[field_name] = text.strip() if text else None
                    logger.debug(f"[{self.name}] Extracted {field_name} = {extracted[field_name]}")
                else:
                    logger.warning(f"[{self.name}] Element not found: {selector}")
                    extracted[field_name] = None
                    
            except Exception as e:
                logger.error(f"[{self.name}] Failed to extract {field_name}: {e}")
                extracted[field_name] = None
        
        return extracted
    
    async def _step_screenshot(self, page: Page, step: Dict):
        """Step: Prendre un screenshot"""
        if not self.config.screenshot_on_error and not step.get('force', False):
            return
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"screenshot_{self.name}_{timestamp}.png"
        
        try:
            await page.screenshot(path=filename)
            self.screenshots.append(filename)
            logger.info(f"[{self.name}] Screenshot saved: {filename}")
        except Exception as e:
            logger.error(f"[{self.name}] Failed to take screenshot: {e}")
    
    async def _step_scroll(self, page: Page, step: Dict):
        """Step: Scroller la page"""
        direction = step.get('direction', 'down')
        amount = step.get('amount', 500)
        
        try:
            if direction == 'down':
                await page.evaluate(f"window.scrollBy(0, {amount})")
            elif direction == 'up':
                await page.evaluate(f"window.scrollBy(0, -{amount})")
            
            await asyncio.sleep(0.5)
        except Exception as e:
            logger.warning(f"[{self.name}] Scroll failed: {e}")
    
    def _build_quote_result(self, extracted_data: Dict[str, Any]) -> QuoteResult:
        """
        Construit un QuoteResult depuis les données extraites
        
        Les scrapers spécifiques peuvent surcharger cette méthode pour
        une logique de transformation plus complexe.
        """
        # Nettoyer et convertir les prix
        price_monthly = self._parse_price(extracted_data.get('price_monthly'))
        price_yearly = self._parse_price(extracted_data.get('price_yearly'))
        
        return QuoteResult(
            price_monthly=price_monthly,
            price_yearly=price_yearly,
            currency=extracted_data.get('currency', 'MAD'),
            quote_reference=extracted_data.get('reference'),
            formula_name=extracted_data.get('formula_name'),
            coverage_details=extracted_data.get('coverage_details', {}),
            additional_info=extracted_data
        )
    
    def _parse_price(self, price_str: Optional[str]) -> Optional[float]:
        """Parse un prix depuis une string"""
        if not price_str:
            return None
        
        try:
            # Nettoyer la string (enlever espaces, devises, etc.)
            clean = price_str.replace(' ', '').replace(',', '.').replace('MAD', '').replace('DH', '')
            
            # Extraire les chiffres
            import re
            match = re.search(r'[\d\.]+', clean)
            if match:
                return float(match.group())
            
            return None
        except Exception as e:
            logger.warning(f"[{self.name}] Failed to parse price '{price_str}': {e}")
            return None
    
    async def handle_errors(self, error: Exception, page: Page) -> None:
        """Gestion centralisée des erreurs (logs, screenshots)"""
        logger.error(f"[{self.name}] Error occurred: {type(error).__name__}: {error}")
        
        # Screenshot en cas d'erreur
        if self.config.screenshot_on_error:
            try:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"error_{self.name}_{timestamp}.png"
                await page.screenshot(path=filename)
                self.screenshots.append(filename)
                logger.info(f"[{self.name}] Error screenshot saved: {filename}")
            except Exception as e:
                logger.error(f"[{self.name}] Failed to take error screenshot: {e}")
    
    async def detect_captcha(self, page: Page) -> bool:
        """Détecte la présence d'un CAPTCHA"""
        captcha_indicators = [
            'recaptcha',
            'captcha',
            'g-recaptcha',
            'hcaptcha',
            'cf-challenge'
        ]
        
        try:
            html = await page.content()
            html_lower = html.lower()
            
            for indicator in captcha_indicators:
                if indicator in html_lower:
                    logger.warning(f"[{self.name}] CAPTCHA detected: {indicator}")
                    return True
            
            return False
        except Exception:
            return False
